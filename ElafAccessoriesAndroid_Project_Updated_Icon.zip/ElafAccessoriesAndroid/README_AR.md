# مشروع تطبيق Elaf Accessories لنظام Android

هذا مشروع Android Studio يفتح متجر Elaf Accessories المنشور على GitHub Pages داخل WebView، مع تفعيل JavaScript وDOM Storage ورفع الصور من لوحة التحكم وفتح روابط واتساب/الهاتف/البريد في التطبيقات المناسبة.

## المتطلبات
- Android Studio حديث.
- JDK 17 (يأتي عادةً مع Android Studio).
- اتصال إنترنت عند أول Gradle Sync وتنزيل Android SDK/المكتبات.

## إنشاء APK تجريبي
1. فك ضغط ملف ZIP.
2. افتح Android Studio.
3. اختر **Open** ثم اختر مجلد `ElafAccessoriesAndroid` (المجلد الذي يحتوي `settings.gradle.kts`).
4. وافق على **Sync Project with Gradle Files** وانتظر تنزيل المتطلبات.
5. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد انتهاء البناء اضغط **locate** من إشعار Android Studio. غالباً ستجد الملف في:
   `app/build/outputs/apk/debug/app-debug.apk`
7. انقل APK إلى الهاتف وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## ملاحظات مهمة
- التطبيق يعرض الموقع المنشور نفسه؛ لذلك يحتاج إلى الإنترنت، وأي تحديث تنشره على الموقع سيظهر في التطبيق دون تحديث APK.
- بيانات المنتجات والطلبات تظل مرتبطة بإعدادات الموقع الحالية وSupabase.
- تمت إضافة دعم اختيار الصور في لوحة الإدارة، وروابط واتساب والروابط الخارجية، وزر الرجوع داخل صفحات المتجر.
- تم تخصيص أيقونة التطبيق باستخدام الصورة التي أرسلتها.
- هذا مشروع مصدر قابل للبناء، وليس ملف APK موقعاً أو مثبتاً مسبقاً. لإنشاء نسخة Release للنشر العام، يلزم إنشاء مفتاح توقيع خاص من Android Studio والاحتفاظ به بأمان.


## خيار بناء APK عبر GitHub Actions
يوجد ملف إعداد جاهز داخل `.github/workflows/android-apk.yml`. إذا رفعت ملفات المشروع إلى مستودع GitHub باسم `main` أو `master`:
1. افتح تبويب **Actions** في المستودع.
2. اختر **Build Elaf Accessories APK** ثم **Run workflow** (أو انتظر انتهاء البناء بعد الرفع).
3. افتح نتيجة التشغيل الناجحة، ومن قسم **Artifacts** نزّل `Elaf-Accessories-debug-apk`.
4. فك ضغط الملف وستجد `app-debug.apk`.

هذه نسخة Debug للتجربة والتثبيت المباشر، وليست نسخة Release موقّعة للنشر في Google Play.
